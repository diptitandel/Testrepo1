# supplygoat
"Vulnerable by Design" supply chain is a learning and training project that demonstrates how common configuration errors can find their way into production cloud environments.
